# SuperGPT for Windows 0.5.11 LAB

This npm package performs the first per-user installation of SuperGPT. It
requires Windows x64, Node.js 22 or later with npm and the official ChatGPT/Codex
app installed for the testing user. Use a regular PowerShell window in that
user's signed-in desktop session. Quit ChatGPT/Codex and SuperGPT from their
menus before running. Use a writable directory such as Downloads.

Download `supergpt-windows-x64-0.5.11-lab.tgz` and verify its SHA-256 against the
published checksum. From the directory with the archive, run:

```powershell
npm.cmd exec --offline --ignore-scripts --yes --package ".\supergpt-windows-x64-0.5.11-lab.tgz" -- supergpt install
```

Use `install --no-launch` to install and leave the apps closed. The package
uses Windows PowerShell to load the managed installation engine directly. It
requires no npm dependencies and does not prompt for elevation. Internal
maintenance code is installed with the desktop components.

The command prints the path to `supergpt-install-*.json` in the working
directory. Send that JSON back to the person who gave you the package. It
records the package and detected Core versions, transaction status, reason
codes and the result of requesting launch. It omits credentials, chat
contents, process arguments and raw exception messages. It does not upload
anything. If npm stops before starting SuperGPT, report the npm error.

`installed` means the SuperGPT transaction committed. The launch result is
reported separately. If launched from a restricted agent session, open the installed SuperGPT
shortcut from the Windows desktop if launch is pending or refused. If prompted,
sign in from the Luma tray menu and verify a Luma response in ChatGPT/Codex.

This pilot uses the same Store/Core compatibility checks as the desktop
product. It only installs into a profile without an active SuperGPT
installation. It is a LAB build and has no production update channel.

## Repack from this repository

Place the matching build's `SuperGPT.Installation.module` and `module.json`
under `native/`, then run `npm pack --ignore-scripts`. The release includes
the exact runtime bytes and metadata. The tracked product commit in the metadata identifies the native engine used
for this build.
